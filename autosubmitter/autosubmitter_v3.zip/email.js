(function () {
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
    console.warn('chrome.storage.local is not available');
    return;
  }

  chrome.storage.local.get(['userEmail'], function (result) {
    const savedEmail = result.userEmail;

    function waitForInputAndButton() {
      const input = document.querySelector('input#username');
      const button = document.querySelector('button[name="action"]');

      if (!input || !button) {
        setTimeout(waitForInputAndButton, 200);
        return;
      }

      if (savedEmail) {
        // Autofill and submit
        input.value = savedEmail;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        console.log('Auto-filled stored email');

        setTimeout(() => {
          button.click();
          console.log('Submitted form with stored email');
        }, 300);
      } else {
        // First-time: user types email, capture on submit
        button.addEventListener('click', function () {
          const enteredEmail = input.value.trim();
          if (enteredEmail) {
            chrome.storage.local.set({ userEmail: enteredEmail }, function () {
              console.log('Stored email for future use:', enteredEmail);
            });
          }
        });
      }
    }

    waitForInputAndButton();
  });
})();
