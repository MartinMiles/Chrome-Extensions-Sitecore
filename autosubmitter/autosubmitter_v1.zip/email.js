function fillAndSubmitEmail() {
  const input = document.querySelector('input#username');
  const button = document.querySelector('button[type="submit"][name="action"][value="default"][data-action-button-primary="true"]');

  if (input && button) {
    input.value = 'martin@zontdigital.com';
    input.dispatchEvent(new Event('input', { bubbles: true }));
    console.log(" Email field filled");

    setTimeout(() => {
      button.click();
      console.log("Submitted email form");
    }, 500); // small delay for stability
  } else {
    console.log("Waiting for input/button...");
    setTimeout(fillAndSubmitEmail, 200);
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', fillAndSubmitEmail);
} else {
  fillAndSubmitEmail();
}
